﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExpired = New System.Windows.Forms.Button()
        Me.btnExpiring = New System.Windows.Forms.Button()
        Me.btnName = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.grpEdit = New System.Windows.Forms.GroupBox()
        Me.txtMachine = New System.Windows.Forms.TextBox()
        Me.lblMachine = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblFirst = New System.Windows.Forms.Label()
        Me.dtpExpire = New System.Windows.Forms.DateTimePicker()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtSnum = New System.Windows.Forms.TextBox()
        Me.txtPnum = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.lblPnum = New System.Windows.Forms.Label()
        Me.lblSerial = New System.Windows.Forms.Label()
        Me.lblExpire = New System.Windows.Forms.Label()
        Me.lblLast = New System.Windows.Forms.Label()
        Me.lstData = New System.Windows.Forms.ListBox()
        Me.grpEdit.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExpired
        '
        Me.btnExpired.Location = New System.Drawing.Point(305, 240)
        Me.btnExpired.Name = "btnExpired"
        Me.btnExpired.Size = New System.Drawing.Size(94, 60)
        Me.btnExpired.TabIndex = 12
        Me.btnExpired.Text = "Expired"
        Me.btnExpired.UseVisualStyleBackColor = True
        '
        'btnExpiring
        '
        Me.btnExpiring.Location = New System.Drawing.Point(305, 135)
        Me.btnExpiring.Name = "btnExpiring"
        Me.btnExpiring.Size = New System.Drawing.Size(94, 60)
        Me.btnExpiring.TabIndex = 11
        Me.btnExpiring.Text = "Expiring"
        Me.btnExpiring.UseVisualStyleBackColor = True
        '
        'btnName
        '
        Me.btnName.Location = New System.Drawing.Point(305, 32)
        Me.btnName.Name = "btnName"
        Me.btnName.Size = New System.Drawing.Size(94, 60)
        Me.btnName.TabIndex = 10
        Me.btnName.Text = "Name"
        Me.btnName.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(31, 487)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(94, 48)
        Me.btnBack.TabIndex = 14
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(183, 487)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(96, 48)
        Me.btnSave.TabIndex = 9
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(305, 349)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(94, 60)
        Me.btnRemove.TabIndex = 13
        Me.btnRemove.Text = "Remove"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(15, 389)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(94, 55)
        Me.btnEdit.TabIndex = 7
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'grpEdit
        '
        Me.grpEdit.Controls.Add(Me.txtMachine)
        Me.grpEdit.Controls.Add(Me.lblMachine)
        Me.grpEdit.Controls.Add(Me.btnAdd)
        Me.grpEdit.Controls.Add(Me.lblFirst)
        Me.grpEdit.Controls.Add(Me.dtpExpire)
        Me.grpEdit.Controls.Add(Me.btnEdit)
        Me.grpEdit.Controls.Add(Me.lblEmail)
        Me.grpEdit.Controls.Add(Me.txtSnum)
        Me.grpEdit.Controls.Add(Me.txtPnum)
        Me.grpEdit.Controls.Add(Me.txtEmail)
        Me.grpEdit.Controls.Add(Me.txtLast)
        Me.grpEdit.Controls.Add(Me.txtFirst)
        Me.grpEdit.Controls.Add(Me.lblPnum)
        Me.grpEdit.Controls.Add(Me.lblSerial)
        Me.grpEdit.Controls.Add(Me.lblExpire)
        Me.grpEdit.Controls.Add(Me.lblLast)
        Me.grpEdit.Location = New System.Drawing.Point(17, 16)
        Me.grpEdit.Name = "grpEdit"
        Me.grpEdit.Size = New System.Drawing.Size(272, 465)
        Me.grpEdit.TabIndex = 7
        Me.grpEdit.TabStop = False
        Me.grpEdit.Text = "Edit Data"
        '
        'txtMachine
        '
        Me.txtMachine.Location = New System.Drawing.Point(141, 241)
        Me.txtMachine.Name = "txtMachine"
        Me.txtMachine.Size = New System.Drawing.Size(125, 27)
        Me.txtMachine.TabIndex = 5
        '
        'lblMachine
        '
        Me.lblMachine.AutoSize = True
        Me.lblMachine.Location = New System.Drawing.Point(58, 244)
        Me.lblMachine.Name = "lblMachine"
        Me.lblMachine.Size = New System.Drawing.Size(68, 20)
        Me.lblMachine.TabIndex = 15
        Me.lblMachine.Text = "Machine:"
        '
        'btnAdd
        '
        Me.btnAdd.Enabled = False
        Me.btnAdd.Location = New System.Drawing.Point(168, 389)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(94, 55)
        Me.btnAdd.TabIndex = 8
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lblFirst
        '
        Me.lblFirst.AutoSize = True
        Me.lblFirst.Location = New System.Drawing.Point(43, 36)
        Me.lblFirst.Name = "lblFirst"
        Me.lblFirst.Size = New System.Drawing.Size(83, 20)
        Me.lblFirst.TabIndex = 5
        Me.lblFirst.Text = "First Name:"
        '
        'dtpExpire
        '
        Me.dtpExpire.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpExpire.Location = New System.Drawing.Point(86, 348)
        Me.dtpExpire.Name = "dtpExpire"
        Me.dtpExpire.Size = New System.Drawing.Size(112, 27)
        Me.dtpExpire.TabIndex = 6
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(77, 118)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(49, 20)
        Me.lblEmail.TabIndex = 3
        Me.lblEmail.Text = "Email:"
        '
        'txtSnum
        '
        Me.txtSnum.Location = New System.Drawing.Point(139, 202)
        Me.txtSnum.Name = "txtSnum"
        Me.txtSnum.Size = New System.Drawing.Size(125, 27)
        Me.txtSnum.TabIndex = 4
        '
        'txtPnum
        '
        Me.txtPnum.Location = New System.Drawing.Point(139, 156)
        Me.txtPnum.Name = "txtPnum"
        Me.txtPnum.Size = New System.Drawing.Size(125, 27)
        Me.txtPnum.TabIndex = 3
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(139, 115)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(125, 27)
        Me.txtEmail.TabIndex = 2
        '
        'txtLast
        '
        Me.txtLast.Location = New System.Drawing.Point(139, 74)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(125, 27)
        Me.txtLast.TabIndex = 1
        '
        'txtFirst
        '
        Me.txtFirst.Location = New System.Drawing.Point(139, 33)
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(125, 27)
        Me.txtFirst.TabIndex = 0
        '
        'lblPnum
        '
        Me.lblPnum.AutoSize = True
        Me.lblPnum.Location = New System.Drawing.Point(15, 159)
        Me.lblPnum.Name = "lblPnum"
        Me.lblPnum.Size = New System.Drawing.Size(111, 20)
        Me.lblPnum.TabIndex = 2
        Me.lblPnum.Text = "Phone Number:"
        '
        'lblSerial
        '
        Me.lblSerial.AutoSize = True
        Me.lblSerial.Location = New System.Drawing.Point(19, 205)
        Me.lblSerial.Name = "lblSerial"
        Me.lblSerial.Size = New System.Drawing.Size(107, 20)
        Me.lblSerial.TabIndex = 1
        Me.lblSerial.Text = "Serial Number:"
        '
        'lblExpire
        '
        Me.lblExpire.AutoSize = True
        Me.lblExpire.Location = New System.Drawing.Point(44, 306)
        Me.lblExpire.Name = "lblExpire"
        Me.lblExpire.Size = New System.Drawing.Size(178, 20)
        Me.lblExpire.TabIndex = 0
        Me.lblExpire.Text = "Warranty Expiration Date:"
        '
        'lblLast
        '
        Me.lblLast.AutoSize = True
        Me.lblLast.Location = New System.Drawing.Point(44, 77)
        Me.lblLast.Name = "lblLast"
        Me.lblLast.Size = New System.Drawing.Size(82, 20)
        Me.lblLast.TabIndex = 4
        Me.lblLast.Text = "Last Name:"
        '
        'lstData
        '
        Me.lstData.FormattingEnabled = True
        Me.lstData.HorizontalScrollbar = True
        Me.lstData.ItemHeight = 20
        Me.lstData.Location = New System.Drawing.Point(426, 16)
        Me.lstData.Name = "lstData"
        Me.lstData.Size = New System.Drawing.Size(325, 524)
        Me.lstData.Sorted = True
        Me.lstData.TabIndex = 0
        '
        'frmAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PeachPuff
        Me.ClientSize = New System.Drawing.Size(775, 560)
        Me.Controls.Add(Me.lstData)
        Me.Controls.Add(Me.grpEdit)
        Me.Controls.Add(Me.btnRemove)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnName)
        Me.Controls.Add(Me.btnExpiring)
        Me.Controls.Add(Me.btnExpired)
        Me.Name = "frmAdmin"
        Me.Text = "Warranty Management System"
        Me.grpEdit.ResumeLayout(False)
        Me.grpEdit.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExpired As Button
    Friend WithEvents btnExpiring As Button
    Friend WithEvents btnName As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnEdit As Button
    Friend WithEvents grpEdit As GroupBox
    Friend WithEvents lstData As ListBox
    Friend WithEvents lblFirst As Label
    Friend WithEvents lblLast As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents lblPnum As Label
    Friend WithEvents lblSerial As Label
    Friend WithEvents lblExpire As Label
    Friend WithEvents txtSnum As TextBox
    Friend WithEvents txtPnum As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtFirst As TextBox
    Friend WithEvents dtpExpire As DateTimePicker
    Friend WithEvents btnAdd As Button
    Friend WithEvents txtMachine As TextBox
    Friend WithEvents lblMachine As Label
End Class
