﻿Imports System.Diagnostics.Eventing.Reader
Imports System.IO
Public Class frmAdmin
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'ask the user if they have saved before exiting
        Dim result As DialogResult = MessageBox.Show("Have You Saved First?", "Are You Sure You Want to Exit?", MessageBoxButtons.YesNo)
        'if yes then exit to home page
        If result = DialogResult.Yes Then
            Me.Hide()
            frmLogin.Show()
        End If



    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        'declare the text file and strings
        Dim totaldetails As StreamReader = File.OpenText("WarrantyData.txt")
        Dim strdetails As String
        Dim strsplit(6) As String
        'check if there is data in the list box
        If lstData.SelectedIndex <> -1 Then
            'copy the list box to a string
            strdetails = lstData.Items(lstData.SelectedIndex)
            'remove the selected entry from the list box
            lstData.Items.Remove(lstData.Text)
            'split the selected entry
            strsplit = strdetails.Split("|")
            'copy all components of the string into its text box
            txtFirst.Text = strsplit(0)
            txtLast.Text = strsplit(1)
            txtEmail.Text = strsplit(2)
            txtPnum.Text = strsplit(3)
            txtSnum.Text = strsplit(4)
            txtMachine.Text = strsplit(5)
            dtpExpire.Value = strsplit(6)
        Else
            'tell the user to select an entry
            MsgBox("Please select an entry", , "Select an Entry")
        End If
        'enable the add button
        btnAdd.Enabled = True
    End Sub

    Private Sub frmAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'declare the variables
        Dim totaldetails As StreamReader = File.OpenText("WarrantyData.txt")
        Dim strdetails As String

        'check the next line in the text file
        Do While totaldetails.Peek <> -1
            strdetails = totaldetails.ReadLine()

            'add the text file to the list box
            lstData.Items.Add(strdetails)

        Loop

        'close the list box
        totaldetails.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'declare the string
        Dim str As String
        'ensure each text box is filled
        If txtFirst.Text = "" Or txtLast.Text = "" Or txtEmail.Text = "" Or txtPnum.Text = "" Or txtSnum.Text = "" Or txtMachine.Text = "" Then
            MsgBox("Please fill in each text box" + vbCrLf + "If no data applicable type N/A", , "Fill All Data")
        Else
            'convert the inputs into string
            str = txtFirst.Text + "|" + txtLast.Text + "|" + txtEmail.Text + "|" + txtPnum.Text + "|" + txtSnum.Text + "|" + txtMachine.Text + "|" + dtpExpire.Text
            'add string to list box
            lstData.Items.Add(str)
            'reset text boxes
            txtFirst.Text = ""
            txtLast.Text = ""
            txtEmail.Text = ""
            txtPnum.Text = ""
            txtSnum.Text = ""
            txtMachine.Text = ""
            dtpExpire.Value = Today
        End If
        'disable the add button
        btnAdd.Enabled = False
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'delcare the text file
        Dim totaldetails As StreamWriter = File.CreateText("WarrantyData.txt")
        'save each item from the list box into the text file
        For Each name As Object In lstData.Items
            totaldetails.WriteLine(name)

        Next
        'close the text file
        totaldetails.Close()
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        'remove the selected index from the list box
        If lstData.SelectedIndex <> -1 Then
            lstData.Items.Remove(lstData.Text)
        Else
            'alert the user that no item was selected
            MsgBox("Please Select User Information", , "Select an Entry")
        End If
    End Sub

    Private Sub btnName_Click(sender As Object, e As EventArgs) Handles btnName.Click
        'declare the variables
        Dim totaldetails As StreamReader = File.OpenText("WarrantyData.txt")
        Dim strdetails As String

        lstData.Items.Clear()

        'check the next line in the text file
        Do While totaldetails.Peek <> -1
            strdetails = totaldetails.ReadLine()

            'add the text file to the list box
            lstData.Items.Add(strdetails)

        Loop

        'close the list box
        totaldetails.Close()

    End Sub

    Private Sub btnExpired_Click(sender As Object, e As EventArgs) Handles btnExpired.Click
        'declare vairables
        Dim totaldetails As StreamReader = File.OpenText("WarrantyData.txt")
        Dim strinfo As String
        Dim strdetails As String
        Dim strSplit(6) As String
        Dim index As Integer
        Dim listsize As Integer
        Dim diff As Integer
        Dim expdate As Date
        'clear the list box
        lstData.Items.Clear()

        'check the next line in the text file
        Do While totaldetails.Peek <> -1
            strinfo = totaldetails.ReadLine()

            'add the text file to the list box
            lstData.Items.Add(strinfo)

        Loop

        'set index to 0
        index = 0
        'declare the size of the list
        listsize = lstData.Items.Count
        'while index is less or equal to the list size
        Do While index <= listsize - 1
            'take the string and split it to find to date difference
            strdetails = lstData.Items(index).ToString
            strSplit = strdetails.Split("|")
            expdate = strSplit(6)
            diff = DateDiff(DateInterval.Day, Today, expdate)
            'if the date difference is positive then remove it from the list box
            If diff > 0 Then
                lstData.Items.Remove(lstData.Items(index))

                listsize = listsize - 1
            Else
                'move to the next line
                index = index + 1

            End If
        Loop
        'close the text file
        totaldetails.Close()
    End Sub

    Private Sub btnExpiring_Click(sender As Object, e As EventArgs) Handles btnExpiring.Click
        'declare the variables
        Dim totaldetails As StreamReader = File.OpenText("WarrantyData.txt")
        Dim strinfo As String
        Dim strdetails As String
        Dim strSplit(6) As String
        Dim index As Integer
        Dim listsize As Integer
        Dim diff As Integer
        Dim expdate As Date
        'clear the list box
        lstData.Items.Clear()

        'check the next line in the text file
        Do While totaldetails.Peek <> -1
            strinfo = totaldetails.ReadLine()

            'add the text file to the list box
            lstData.Items.Add(strinfo)

        Loop
        'set index to 0
        index = 0
        'declare the list size
        listsize = lstData.Items.Count
        'while index is less or equal to the list size
        Do While index <= listsize - 1
            'split the string 
            strdetails = lstData.Items(index).ToString
            strSplit = strdetails.Split("|")
            'calculate the date different taking todays date away from the expiration date
            expdate = strSplit(6)
            diff = DateDiff(DateInterval.Day, Today, expdate)
            'if the date difference is greater then 7 or less then 0 then remove it from the list box
            If diff > 7 OrElse diff < 0 Then
                lstData.Items.Remove(lstData.Items(index))

                listsize = listsize - 1
            Else
                'move to the next index
                index = index + 1

            End If
        Loop
        'close the text file
        totaldetails.Close()


    End Sub
End Class