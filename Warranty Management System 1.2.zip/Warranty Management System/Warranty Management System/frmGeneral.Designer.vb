﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmGeneral
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnExport = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.lblFirst = New System.Windows.Forms.Label()
        Me.lblLast = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblPnum = New System.Windows.Forms.Label()
        Me.lblSnum = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.grpInput = New System.Windows.Forms.GroupBox()
        Me.txtMachine = New System.Windows.Forms.TextBox()
        Me.lblMachine = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.dtpExpire = New System.Windows.Forms.DateTimePicker()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.txtSnum = New System.Windows.Forms.TextBox()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.txtPnum = New System.Windows.Forms.TextBox()
        Me.grpSearch = New System.Windows.Forms.GroupBox()
        Me.rdbMachine = New System.Windows.Forms.RadioButton()
        Me.rdbPhone = New System.Windows.Forms.RadioButton()
        Me.rdbSerial = New System.Windows.Forms.RadioButton()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.lstInputs = New System.Windows.Forms.ListBox()
        Me.txtInfo = New System.Windows.Forms.TextBox()
        Me.grpInput.SuspendLayout()
        Me.grpSearch.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(446, 12)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(131, 49)
        Me.btnBack.TabIndex = 15
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(161, 424)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 61)
        Me.btnSave.TabIndex = 8
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnExport
        '
        Me.btnExport.Enabled = False
        Me.btnExport.Location = New System.Drawing.Point(169, 225)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(110, 63)
        Me.btnExport.TabIndex = 14
        Me.btnExport.Text = "Export"
        Me.btnExport.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Enabled = False
        Me.btnSearch.Location = New System.Drawing.Point(6, 225)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(107, 63)
        Me.btnSearch.TabIndex = 13
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'lblFirst
        '
        Me.lblFirst.AutoSize = True
        Me.lblFirst.Location = New System.Drawing.Point(38, 57)
        Me.lblFirst.Name = "lblFirst"
        Me.lblFirst.Size = New System.Drawing.Size(83, 20)
        Me.lblFirst.TabIndex = 4
        Me.lblFirst.Text = "First Name:"
        '
        'lblLast
        '
        Me.lblLast.AutoSize = True
        Me.lblLast.Location = New System.Drawing.Point(39, 104)
        Me.lblLast.Name = "lblLast"
        Me.lblLast.Size = New System.Drawing.Size(82, 20)
        Me.lblLast.TabIndex = 5
        Me.lblLast.Text = "Last Name:"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(72, 156)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(49, 20)
        Me.lblEmail.TabIndex = 6
        Me.lblEmail.Text = "Email:"
        '
        'lblPnum
        '
        Me.lblPnum.AutoSize = True
        Me.lblPnum.Location = New System.Drawing.Point(10, 208)
        Me.lblPnum.Name = "lblPnum"
        Me.lblPnum.Size = New System.Drawing.Size(111, 20)
        Me.lblPnum.TabIndex = 7
        Me.lblPnum.Text = "Phone Number:"
        '
        'lblSnum
        '
        Me.lblSnum.AutoSize = True
        Me.lblSnum.Location = New System.Drawing.Point(14, 264)
        Me.lblSnum.Name = "lblSnum"
        Me.lblSnum.Size = New System.Drawing.Size(107, 20)
        Me.lblSnum.TabIndex = 8
        Me.lblSnum.Text = "Serial Number:"
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Location = New System.Drawing.Point(60, 357)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(178, 20)
        Me.lblDate.TabIndex = 9
        Me.lblDate.Text = "Warranty Expiration Date:"
        '
        'grpInput
        '
        Me.grpInput.Controls.Add(Me.txtMachine)
        Me.grpInput.Controls.Add(Me.lblMachine)
        Me.grpInput.Controls.Add(Me.btnAdd)
        Me.grpInput.Controls.Add(Me.dtpExpire)
        Me.grpInput.Controls.Add(Me.txtEmail)
        Me.grpInput.Controls.Add(Me.txtFirst)
        Me.grpInput.Controls.Add(Me.txtSnum)
        Me.grpInput.Controls.Add(Me.btnSave)
        Me.grpInput.Controls.Add(Me.txtLast)
        Me.grpInput.Controls.Add(Me.lblFirst)
        Me.grpInput.Controls.Add(Me.lblLast)
        Me.grpInput.Controls.Add(Me.lblEmail)
        Me.grpInput.Controls.Add(Me.lblPnum)
        Me.grpInput.Controls.Add(Me.lblSnum)
        Me.grpInput.Controls.Add(Me.lblDate)
        Me.grpInput.Controls.Add(Me.txtPnum)
        Me.grpInput.Location = New System.Drawing.Point(12, 40)
        Me.grpInput.Name = "grpInput"
        Me.grpInput.Size = New System.Drawing.Size(303, 504)
        Me.grpInput.TabIndex = 13
        Me.grpInput.TabStop = False
        Me.grpInput.Text = "Input Data"
        '
        'txtMachine
        '
        Me.txtMachine.Location = New System.Drawing.Point(127, 310)
        Me.txtMachine.MaxLength = 9
        Me.txtMachine.Name = "txtMachine"
        Me.txtMachine.Size = New System.Drawing.Size(160, 27)
        Me.txtMachine.TabIndex = 5
        '
        'lblMachine
        '
        Me.lblMachine.AutoSize = True
        Me.lblMachine.Location = New System.Drawing.Point(53, 313)
        Me.lblMachine.Name = "lblMachine"
        Me.lblMachine.Size = New System.Drawing.Size(68, 20)
        Me.lblMachine.TabIndex = 10
        Me.lblMachine.Text = "Machine:"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(13, 424)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(125, 61)
        Me.btnAdd.TabIndex = 7
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'dtpExpire
        '
        Me.dtpExpire.CustomFormat = ""
        Me.dtpExpire.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpExpire.Location = New System.Drawing.Point(127, 391)
        Me.dtpExpire.Name = "dtpExpire"
        Me.dtpExpire.Size = New System.Drawing.Size(159, 27)
        Me.dtpExpire.TabIndex = 6
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(127, 153)
        Me.txtEmail.MaxLength = 30
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(160, 27)
        Me.txtEmail.TabIndex = 2
        '
        'txtFirst
        '
        Me.txtFirst.Location = New System.Drawing.Point(127, 54)
        Me.txtFirst.MaxLength = 15
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(160, 27)
        Me.txtFirst.TabIndex = 0
        '
        'txtSnum
        '
        Me.txtSnum.Location = New System.Drawing.Point(127, 261)
        Me.txtSnum.MaxLength = 9
        Me.txtSnum.Name = "txtSnum"
        Me.txtSnum.Size = New System.Drawing.Size(160, 27)
        Me.txtSnum.TabIndex = 4
        '
        'txtLast
        '
        Me.txtLast.Location = New System.Drawing.Point(127, 101)
        Me.txtLast.MaxLength = 15
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(160, 27)
        Me.txtLast.TabIndex = 1
        '
        'txtPnum
        '
        Me.txtPnum.Location = New System.Drawing.Point(127, 205)
        Me.txtPnum.MaxLength = 10
        Me.txtPnum.Name = "txtPnum"
        Me.txtPnum.Size = New System.Drawing.Size(160, 27)
        Me.txtPnum.TabIndex = 3
        '
        'grpSearch
        '
        Me.grpSearch.Controls.Add(Me.rdbMachine)
        Me.grpSearch.Controls.Add(Me.rdbPhone)
        Me.grpSearch.Controls.Add(Me.rdbSerial)
        Me.grpSearch.Controls.Add(Me.txtSearch)
        Me.grpSearch.Controls.Add(Me.btnSearch)
        Me.grpSearch.Controls.Add(Me.btnExport)
        Me.grpSearch.Location = New System.Drawing.Point(697, 40)
        Me.grpSearch.Name = "grpSearch"
        Me.grpSearch.Size = New System.Drawing.Size(285, 303)
        Me.grpSearch.TabIndex = 0
        Me.grpSearch.TabStop = False
        Me.grpSearch.Text = "Search (Case Sensitive)"
        '
        'rdbMachine
        '
        Me.rdbMachine.AutoSize = True
        Me.rdbMachine.Location = New System.Drawing.Point(6, 133)
        Me.rdbMachine.Name = "rdbMachine"
        Me.rdbMachine.Size = New System.Drawing.Size(86, 24)
        Me.rdbMachine.TabIndex = 11
        Me.rdbMachine.TabStop = True
        Me.rdbMachine.Text = "Machine"
        Me.rdbMachine.UseVisualStyleBackColor = True
        '
        'rdbPhone
        '
        Me.rdbPhone.AutoSize = True
        Me.rdbPhone.Location = New System.Drawing.Point(6, 87)
        Me.rdbPhone.Name = "rdbPhone"
        Me.rdbPhone.Size = New System.Drawing.Size(129, 24)
        Me.rdbPhone.TabIndex = 10
        Me.rdbPhone.TabStop = True
        Me.rdbPhone.Text = "Phone Number"
        Me.rdbPhone.UseVisualStyleBackColor = True
        '
        'rdbSerial
        '
        Me.rdbSerial.AutoSize = True
        Me.rdbSerial.Location = New System.Drawing.Point(6, 40)
        Me.rdbSerial.Name = "rdbSerial"
        Me.rdbSerial.Size = New System.Drawing.Size(125, 24)
        Me.rdbSerial.TabIndex = 9
        Me.rdbSerial.TabStop = True
        Me.rdbSerial.Text = "Serial Number"
        Me.rdbSerial.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(6, 175)
        Me.txtSearch.MaxLength = 10
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(273, 27)
        Me.txtSearch.TabIndex = 12
        '
        'lstInputs
        '
        Me.lstInputs.FormattingEnabled = True
        Me.lstInputs.HorizontalScrollbar = True
        Me.lstInputs.ItemHeight = 20
        Me.lstInputs.Location = New System.Drawing.Point(339, 80)
        Me.lstInputs.Name = "lstInputs"
        Me.lstInputs.Size = New System.Drawing.Size(338, 464)
        Me.lstInputs.Sorted = True
        Me.lstInputs.TabIndex = 1
        '
        'txtInfo
        '
        Me.txtInfo.Location = New System.Drawing.Point(703, 371)
        Me.txtInfo.Multiline = True
        Me.txtInfo.Name = "txtInfo"
        Me.txtInfo.ReadOnly = True
        Me.txtInfo.Size = New System.Drawing.Size(273, 173)
        Me.txtInfo.TabIndex = 12
        '
        'frmGeneral
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PeachPuff
        Me.ClientSize = New System.Drawing.Size(992, 574)
        Me.Controls.Add(Me.txtInfo)
        Me.Controls.Add(Me.grpSearch)
        Me.Controls.Add(Me.lstInputs)
        Me.Controls.Add(Me.grpInput)
        Me.Controls.Add(Me.btnBack)
        Me.Name = "frmGeneral"
        Me.Text = "Warranty Management System"
        Me.grpInput.ResumeLayout(False)
        Me.grpInput.PerformLayout()
        Me.grpSearch.ResumeLayout(False)
        Me.grpSearch.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBack As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents btnExport As Button
    Friend WithEvents btnSearch As Button
    Friend WithEvents lblFirst As Label
    Friend WithEvents lblLast As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents lblPnum As Label
    Friend WithEvents lblSnum As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents grpInput As GroupBox
    Friend WithEvents dtpExpire As DateTimePicker
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtFirst As TextBox
    Friend WithEvents txtSnum As TextBox
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtPnum As TextBox
    Friend WithEvents grpSearch As GroupBox
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents lstInputs As ListBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents txtInfo As TextBox
    Friend WithEvents txtMachine As TextBox
    Friend WithEvents lblMachine As Label
    Friend WithEvents rdbMachine As RadioButton
    Friend WithEvents rdbPhone As RadioButton
    Friend WithEvents rdbSerial As RadioButton
End Class
