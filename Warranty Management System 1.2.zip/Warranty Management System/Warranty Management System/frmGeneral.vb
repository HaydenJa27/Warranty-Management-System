﻿Imports System.Diagnostics.Eventing.Reader
Imports System.IO
Imports System.Runtime.Serialization
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frmGeneral

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'ask user if they have saved
        Dim result As DialogResult = MessageBox.Show("Have You Saved First?", "Are You Sure You Want to Exit?", MessageBoxButtons.YesNo)
        'if they say yes then exit to home page
        If result = DialogResult.Yes Then
            Me.Hide()
            frmLogin.Show()
        End If

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'open text tile
        Dim totaldetails As StreamWriter = File.CreateText("WarrantyData.txt")
        'save each item in list box to the text file
        For Each name As Object In lstInputs.Items
            totaldetails.WriteLine(name)

        Next
        'close the text file
        totaldetails.Close()

    End Sub

    Private Sub frmGeneral_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'declare the variables
        Dim totaldetails As StreamReader = File.OpenText("WarrantyData.txt")
        Dim strdetails As String

        'check the next line in the text file
        Do While totaldetails.Peek <> -1
            strdetails = totaldetails.ReadLine()

            'add the text file to the list box
            lstInputs.Items.Add(strdetails)

        Loop

        'close the list
        totaldetails.Close()

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'declare the string
        Dim str As String
        'ensure each text box is filled
        If txtFirst.Text = "" Or txtLast.Text = "" Or txtEmail.Text = "" Or txtPnum.Text = "" Or txtSnum.Text = "" Or txtMachine.Text = "" Then
            MsgBox("Please fill in each text box" + vbCrLf + "If no data applicable type N/A", , "Fill All Data")
        Else
            'convert the inputs into string
            str = txtFirst.Text + "|" + txtLast.Text + "|" + txtEmail.Text + "|" + txtPnum.Text + "|" + txtSnum.Text + "|" + txtMachine.Text + "|" + dtpExpire.Text
            'add string to list box
            lstInputs.Items.Add(str)
            'reset text boxes
            txtFirst.Text = ""
            txtLast.Text = ""
            txtEmail.Text = ""
            txtPnum.Text = ""
            txtSnum.Text = ""
            txtMachine.Text = ""
            dtpExpire.Value = Today
        End If





    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        'declare the variables
        Dim Found As Boolean
        Dim index As Integer
        Dim target As String
        Dim listsize As Integer
        Dim strSplit(6) As String
        Dim strDetails As String
        'set the index counter to 0
        index = 0
        'ensure there is nothing found at the start
        Found = False
        'the size of the search is based on the items in the list box
        listsize = lstInputs.Items.Count
        'the targer it what was typed by the user
        target = txtSearch.Text



        '
        Do While (Found = False) And (index <= listsize - 1) And (txtSearch.Text <> "")
            'Read in next line
            strDetails = lstInputs.Items(index).ToString
            'split line
            strSplit = strDetails.Split("|")
            'if the serial number button is checked see if there is a matching result in the list box
            If rdbSerial.Checked = True Then
                If strSplit(4) = target Then
                    Found = True
                Else
                    'search the next line
                    index = index + 1

                End If
                'if the phone number button is checked see if there is a matching result in the list box
            ElseIf rdbPhone.Checked = True Then
                If strSplit(3) = target Then
                    Found = True
                Else
                    'search the next line
                    index = index + 1

                End If
                ''if the machine button is checked see if there is a matching result in the list box
            ElseIf rdbMachine.Checked = True Then
                If strSplit(5) = target Then
                    Found = True
                Else
                    'search the next line
                    index = index + 1

                End If
            Else


            End If

        Loop
        'if the search is found put in the text box
        If Found = True Then
            txtInfo.Text = strDetails
        End If
    End Sub

    Private Sub btnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click

        'declare string
        Dim strfile As String
        'ask user to enter a file name
        strfile = InputBox("Please Name the file", , "File Name")
        'create and name the file
        Dim details As StreamWriter = File.CreateText(strfile & ".txt")
        'write the searched text to the file
        details.WriteLine(txtInfo.Text)

        'tell the user the file has been made and close the file
        MsgBox("Your file has been saved", , "File Saved")
        details.Close()
        'disable the button
        btnExport.Enabled = False
        'set the text boxes back to empty
        txtInfo.Text = ""
        txtSearch.Text = ""
    End Sub

    Private Sub rdbSerial_CheckedChanged(sender As Object, e As EventArgs) Handles rdbSerial.CheckedChanged
        'enable the search button
        btnSearch.Enabled = True
    End Sub

    Private Sub rdbPhone_CheckedChanged(sender As Object, e As EventArgs) Handles rdbPhone.CheckedChanged
        'enable the search button
        btnSearch.Enabled = True
    End Sub

    Private Sub rdbMachine_CheckedChanged(sender As Object, e As EventArgs) Handles rdbMachine.CheckedChanged
        'enable the search button
        btnSearch.Enabled = True
    End Sub

    Private Sub txtInfo_TextChanged(sender As Object, e As EventArgs) Handles txtInfo.TextChanged
        'enable export button
        btnExport.Enabled = True
    End Sub
End Class