﻿Imports System.Diagnostics.Eventing.Reader

Public Class frmLogin


    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        'if the login information is correct give access to the form
        If txtUsername.Text = "StihlUser" Then
            If txtPassword.Text = "User-123" Then
                Me.Hide()
                frmGeneral.Show()
            Else
                'alert the user that the information is incorrect
                MsgBox("Your Username or Password is Incorrect")

            End If
            'if the login informaiton is correct give access to the form 
        ElseIf txtUsername.Text = "StihlAdmin" Then
            If txtPassword.Text = "Admin-123" Then
                Me.Hide()
                frmAdmin.Show()
            Else
                'alert the user that the information is incorrect
                MsgBox("Your Username or Password is Incorrect")

            End If
        Else
            'alert the user that the information is incorrect
            MsgBox("Your Username or Password is Incorrect")

        End If
        'reset the text boxes
        txtPassword.Text = ""
        txtUsername.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'close the program
        Me.Close()
    End Sub
End Class